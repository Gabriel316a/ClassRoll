Add your app icons here:
- icon-192.png (192x192px)
- icon-512.png (512x512px)

These are referenced in /public/manifest.json and are what students
see when they "Add to Home Screen." Any square PNG logo works —
you can generate both sizes free at https://realfavicongenerator.net
