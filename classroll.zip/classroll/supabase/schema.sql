-- Run this once in the Supabase SQL editor (Project > SQL Editor > New query)

-- Class sessions created by an HOC
create table sessions (
  id uuid primary key default gen_random_uuid(),
  hoc_id uuid references auth.users(id) not null,
  class_name text not null,
  custom_fields jsonb default '[]',
  is_open boolean default true,
  created_at timestamptz default now()
);

-- Student submissions against a session
create table submissions (
  id uuid primary key default gen_random_uuid(),
  session_id uuid references sessions(id) not null,
  name text not null,
  matric_number text not null,
  custom_values jsonb default '{}',
  signature_path text not null,
  status text default 'pending', -- 'pending' | 'validated'
  submitted_at timestamptz default now()
);

-- Registry of which auth users are allowed into /superadmin
create table super_admins (
  user_id uuid references auth.users(id) primary key
);

-- Single-row table holding the app-wide kill switch
create table app_settings (
  id int primary key default 1,
  app_status text default 'live' -- 'live' | 'maintenance'
);
insert into app_settings (id, app_status) values (1, 'live');

-- Storage bucket for signature images (create via Storage tab, or here)
insert into storage.buckets (id, name, public) values ('signatures', 'signatures', false)
on conflict (id) do nothing;

-- Basic RLS: enable it, then add policies matching your access rules.
alter table sessions enable row level security;
alter table submissions enable row level security;
alter table app_settings enable row level security;

-- Students can insert submissions into any open session (no login required)
create policy "anyone can submit" on submissions
  for insert with check (true);

-- Anyone can read a session to load the student form
create policy "anyone can read sessions" on sessions
  for select using (true);

-- Only the owning HOC can manage their own sessions/submissions
create policy "hoc manages own sessions" on sessions
  for all using (auth.uid() = hoc_id);

create policy "hoc reads own submissions" on submissions
  for select using (
    exists (select 1 from sessions where sessions.id = submissions.session_id and sessions.hoc_id = auth.uid())
  );

create policy "hoc validates own submissions" on submissions
  for update using (
    exists (select 1 from sessions where sessions.id = submissions.session_id and sessions.hoc_id = auth.uid())
  );

-- Anyone can read app_settings (needed for the maintenance check on every page)
create policy "anyone reads app_settings" on app_settings
  for select using (true);
