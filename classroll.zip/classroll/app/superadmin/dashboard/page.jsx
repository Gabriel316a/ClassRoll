"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function SuperAdminDashboardPage() {
  const [status, setStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStatus();
  }, []);

  async function loadStatus() {
    const { data } = await supabase
      .from("app_settings")
      .select("app_status")
      .eq("id", 1)
      .single();

    setStatus(data?.app_status || "live");
    setLoading(false);
  }

  async function toggleStatus() {
    const next = status === "live" ? "maintenance" : "live";
    const { error } = await supabase
      .from("app_settings")
      .update({ app_status: next })
      .eq("id", 1);

    if (!error) setStatus(next);
  }

  if (loading) return <p className="text-center py-16">Loading…</p>;

  return (
    <div className="max-w-md mx-auto px-6 py-16 text-center">
      <h1 className="text-xl font-semibold mb-6">Super Admin</h1>

      <div className="border rounded-lg p-6">
        <p className="text-sm text-gray-500 mb-1">Current app status</p>
        <p
          className={`text-lg font-medium mb-4 ${
            status === "live" ? "text-green-600" : "text-amber-600"
          }`}
        >
          {status === "live" ? "Live" : "Maintenance mode"}
        </p>

        <button
          onClick={toggleStatus}
          className={`w-full rounded-md py-2 font-medium text-white ${
            status === "live" ? "bg-red-600" : "bg-green-600"
          }`}
        >
          {status === "live" ? "Shut down app" : "Bring app back live"}
        </button>

        <p className="text-xs text-gray-400 mt-4">
          Locks out students and HOCs, not you. No data is deleted or affected.
        </p>
      </div>
    </div>
  );
}
