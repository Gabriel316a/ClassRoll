import "./globals.css";
import Footer from "@/components/Footer";
import MaintenanceGate from "@/components/MaintenanceGate";

export const metadata = {
  title: "ClassRoll",
  description: "Fast digital attendance and signature collection for classes",
  manifest: "/manifest.json",
};

export const viewport = {
  themeColor: "#4f46e5",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col">
        <MaintenanceGate>
          <main className="flex-1">{children}</main>
        </MaintenanceGate>
        <Footer />
      </body>
    </html>
  );
}
