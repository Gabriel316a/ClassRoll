import { NextResponse } from "next/server";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { createClient } from "@supabase/supabase-js";

// Uses the service role key server-side only — never exposed to the browser.
const supabaseAdmin = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

export async function POST(request) {
  const { sessionId } = await request.json();

  const { data: session } = await supabaseAdmin
    .from("sessions")
    .select("class_name")
    .eq("id", sessionId)
    .single();

  const { data: submissions } = await supabaseAdmin
    .from("submissions")
    .select("name, matric_number, signature_path")
    .eq("session_id", sessionId)
    .eq("status", "validated")
    .order("name", { ascending: true });

  const pdfDoc = await PDFDocument.create();
  const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

  let page = pdfDoc.addPage();
  const { height } = page.getSize();
  let y = height - 60;

  page.drawText(session?.class_name || "Attendance Sheet", {
    x: 50,
    y,
    size: 16,
    font,
  });
  y -= 40;

  for (const submission of submissions || []) {
    if (y < 120) {
      page = pdfDoc.addPage();
      y = height - 60;
    }

    page.drawText(`${submission.name}  (${submission.matric_number})`, {
      x: 50,
      y,
      size: 11,
      font,
      color: rgb(0, 0, 0),
    });
    y -= 16;

    const { data: fileData } = await supabaseAdmin.storage
      .from("signatures")
      .download(submission.signature_path);

    if (fileData) {
      const bytes = new Uint8Array(await fileData.arrayBuffer());
      const isPng = submission.signature_path.toLowerCase().endsWith(".png");
      const image = isPng
        ? await pdfDoc.embedPng(bytes)
        : await pdfDoc.embedJpg(bytes);

      const scaled = image.scale(60 / image.height);
      page.drawImage(image, { x: 300, y: y - 45, width: scaled.width, height: 60 });
    }

    y -= 70;
  }

  const pdfBytes = await pdfDoc.save();

  return new NextResponse(pdfBytes, {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": "attachment; filename=attendance.pdf",
    },
  });
}
