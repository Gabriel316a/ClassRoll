"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";

export default function HocDashboardPage() {
  const [sessions, setSessions] = useState([]);
  const [selectedSessionId, setSelectedSessionId] = useState(null);
  const [submissions, setSubmissions] = useState([]);

  const [className, setClassName] = useState("");
  const [customFields, setCustomFields] = useState([]);

  useEffect(() => {
    loadSessions();
  }, []);

  useEffect(() => {
    if (selectedSessionId) loadSubmissions(selectedSessionId);
  }, [selectedSessionId]);

  async function loadSessions() {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { data } = await supabase
      .from("sessions")
      .select("id, class_name, is_open, created_at")
      .eq("hoc_id", user.id)
      .order("created_at", { ascending: false });

    setSessions(data || []);
  }

  async function loadSubmissions(sessionId) {
    const { data } = await supabase
      .from("submissions")
      .select("id, name, matric_number, status, signature_path, submitted_at")
      .eq("session_id", sessionId)
      .order("submitted_at", { ascending: true });

    setSubmissions(data || []);
  }

  function addCustomField() {
    setCustomFields((prev) => [...prev, { name: "", label: "", required: true }]);
  }

  function updateCustomField(index, key, value) {
    setCustomFields((prev) =>
      prev.map((f, i) => (i === index ? { ...f, [key]: value } : f))
    );
  }

  async function createSession(e) {
    e.preventDefault();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const { error } = await supabase.from("sessions").insert({
      hoc_id: user.id,
      class_name: className,
      custom_fields: customFields,
      is_open: true,
    });

    if (!error) {
      setClassName("");
      setCustomFields([]);
      loadSessions();
    }
  }

  async function validateSubmission(id) {
    await supabase.from("submissions").update({ status: "validated" }).eq("id", id);
    loadSubmissions(selectedSessionId);
  }

  async function approveAll() {
    const pendingIds = submissions.filter((s) => s.status === "pending").map((s) => s.id);
    if (pendingIds.length === 0) return;

    await supabase.from("submissions").update({ status: "validated" }).in("id", pendingIds);
    loadSubmissions(selectedSessionId);
  }

  async function exportPdf() {
    // Hits a server route that pulls validated submissions + signature
    // images and compiles them into a PDF using the HOC's saved layout.
    const res = await fetch("/api/generate-pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ sessionId: selectedSessionId }),
    });

    if (res.ok) {
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "attendance.pdf";
      a.click();
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-6 py-10">
      <h1 className="text-xl font-semibold mb-6">HOC Dashboard</h1>

      <section className="mb-10 border rounded-lg p-4">
        <h2 className="font-medium mb-3">Create a new session</h2>
        <form onSubmit={createSession} className="flex flex-col gap-3">
          <input
            required
            placeholder="Class name (e.g. CSC 301 - Mon 10AM)"
            value={className}
            onChange={(e) => setClassName(e.target.value)}
            className="border rounded-md px-3 py-2"
          />

          {customFields.map((field, i) => (
            <div key={i} className="flex gap-2">
              <input
                placeholder="Field key (e.g. seat_number)"
                value={field.name}
                onChange={(e) => updateCustomField(i, "name", e.target.value)}
                className="border rounded-md px-3 py-2 flex-1"
              />
              <input
                placeholder="Label shown to student"
                value={field.label}
                onChange={(e) => updateCustomField(i, "label", e.target.value)}
                className="border rounded-md px-3 py-2 flex-1"
              />
            </div>
          ))}

          <button
            type="button"
            onClick={addCustomField}
            className="text-indigo-600 text-sm text-left"
          >
            + Add custom field
          </button>

          <button
            type="submit"
            className="bg-indigo-600 text-white rounded-md py-2 font-medium"
          >
            Create session
          </button>
        </form>
      </section>

      <section className="mb-6">
        <h2 className="font-medium mb-3">Your sessions</h2>
        <ul className="flex flex-col gap-2">
          {sessions.map((s) => (
            <li key={s.id}>
              <button
                onClick={() => setSelectedSessionId(s.id)}
                className={`w-full text-left border rounded-md px-3 py-2 ${
                  selectedSessionId === s.id ? "border-indigo-600" : ""
                }`}
              >
                {s.class_name}{" "}
                <span className="text-xs text-gray-500 ml-2">
                  {s.is_open ? "open" : "closed"}
                </span>
              </button>
              <p className="text-xs text-gray-400 mt-1 ml-1">
                Link: /student/{s.id}
              </p>
            </li>
          ))}
        </ul>
      </section>

      {selectedSessionId && (
        <section>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-medium">Submissions</h2>
            <div className="flex gap-2">
              <button onClick={approveAll} className="text-sm text-indigo-600">
                Approve all
              </button>
              <button onClick={exportPdf} className="text-sm text-indigo-600">
                Export PDF
              </button>
            </div>
          </div>

          <ul className="flex flex-col gap-2">
            {submissions.map((s) => (
              <li
                key={s.id}
                className="flex items-center justify-between border rounded-md px-3 py-2"
              >
                <div>
                  <p className="font-medium">{s.name}</p>
                  <p className="text-xs text-gray-500">{s.matric_number}</p>
                </div>
                {s.status === "pending" ? (
                  <button
                    onClick={() => validateSubmission(s.id)}
                    className="text-sm bg-indigo-600 text-white rounded-md px-3 py-1"
                  >
                    Validate
                  </button>
                ) : (
                  <span className="text-sm text-green-600">Validated</span>
                )}
              </li>
            ))}
          </ul>
        </section>
      )}
    </div>
  );
}
