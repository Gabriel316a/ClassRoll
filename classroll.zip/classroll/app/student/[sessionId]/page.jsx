"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

export default function StudentSubmissionPage() {
  const { sessionId } = useParams();

  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState(null);

  const [name, setName] = useState("");
  const [matricNumber, setMatricNumber] = useState("");
  const [customValues, setCustomValues] = useState({});
  const [signatureFile, setSignatureFile] = useState(null);

  useEffect(() => {
    async function loadSession() {
      const { data, error } = await supabase
        .from("sessions")
        .select("id, class_name, custom_fields, is_open")
        .eq("id", sessionId)
        .single();

      if (error || !data) {
        setError("This attendance link is invalid or has expired.");
      } else if (!data.is_open) {
        setError("This attendance session is closed.");
      } else {
        setSession(data);
      }
      setLoading(false);
    }
    loadSession();
  }, [sessionId]);

  function handleCustomChange(fieldName, value) {
    setCustomValues((prev) => ({ ...prev, [fieldName]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!signatureFile) {
      setError("Please upload a photo of your signature.");
      return;
    }
    setSubmitting(true);
    setError(null);

    try {
      const fileExt = signatureFile.name.split(".").pop();
      const filePath = `${sessionId}/${matricNumber}-${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from("signatures")
        .upload(filePath, signatureFile);

      if (uploadError) throw uploadError;

      const { error: insertError } = await supabase.from("submissions").insert({
        session_id: sessionId,
        name,
        matric_number: matricNumber,
        custom_values: customValues,
        signature_path: filePath,
        status: "pending",
      });

      if (insertError) throw insertError;

      setSubmitted(true);
    } catch (err) {
      setError(err.message || "Something went wrong. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) return <p className="text-center py-16">Loading…</p>;
  if (error && !session) return <p className="text-center py-16 text-red-600">{error}</p>;

  if (submitted) {
    return (
      <div className="max-w-md mx-auto px-6 py-16 text-center">
        <h1 className="text-xl font-semibold mb-2">Submitted ✅</h1>
        <p className="text-gray-500">
          Your details have been sent to your Head of Class for validation.
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-md mx-auto px-6 py-10">
      <h1 className="text-xl font-semibold mb-1">{session.class_name}</h1>
      <p className="text-gray-500 mb-6">Fill in your details to mark attendance.</p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="block text-sm font-medium mb-1">Full name</label>
          <input
            required
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full border rounded-md px-3 py-2"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-1">Matric number</label>
          <input
            required
            value={matricNumber}
            onChange={(e) => setMatricNumber(e.target.value)}
            className="w-full border rounded-md px-3 py-2"
          />
        </div>

        {(session.custom_fields || []).map((field) => (
          <div key={field.name}>
            <label className="block text-sm font-medium mb-1">{field.label}</label>
            <input
              required={field.required}
              value={customValues[field.name] || ""}
              onChange={(e) => handleCustomChange(field.name, e.target.value)}
              className="w-full border rounded-md px-3 py-2"
            />
          </div>
        ))}

        <div>
          <label className="block text-sm font-medium mb-1">Signature photo</label>
          <input
            required
            type="file"
            accept="image/*"
            onChange={(e) => setSignatureFile(e.target.files?.[0] || null)}
            className="w-full text-sm"
          />
        </div>

        {error && <p className="text-red-600 text-sm">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="bg-indigo-600 text-white rounded-md py-2 font-medium disabled:opacity-50"
        >
          {submitting ? "Submitting…" : "Submit"}
        </button>
      </form>
    </div>
  );
}
