export default function HomePage() {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-24 text-center gap-4">
      <h1 className="text-3xl font-bold">ClassRoll</h1>
      <p className="text-gray-500 max-w-md">
        Attendance and signature collection, without the queue. Students
        submit their details through a link shared by their Head of Class.
      </p>
    </div>
  );
}
