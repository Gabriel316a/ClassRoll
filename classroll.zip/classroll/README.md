# ClassRoll

Digital attendance and signature collection. Students submit their details
through a link an HOC (Head of Class) shares; the HOC validates them, then
exports a PDF.

## What's in this scaffold

- `/` — landing page
- `/student/[sessionId]` — student submission form (name, matric number,
  custom fields, signature photo upload)
- `/hoc/login`, `/hoc/dashboard` — HOC creates sessions, validates
  submissions (individually or "approve all"), exports the PDF
- `/superadmin/login`, `/superadmin/dashboard` — your personal kill switch
  to flip the whole app into maintenance mode without touching any data
- `components/MaintenanceGate.jsx` — checks the switch on every page load
- `components/Footer.jsx` — the 💡 Innovation Hub footer, applied globally
  in `app/layout.jsx`
- `app/api/generate-pdf/route.js` — compiles validated submissions +
  signature images into a downloadable PDF (currently a simple list
  layout — this is the place to customize the exact structure you want)
- `supabase/schema.sql` — the database schema to run once in Supabase

## 1. Local setup

```bash
npm install
cp .env.local.example .env.local   # then fill in your Supabase values
npm run dev
```

## 2. Supabase setup (free tier)

1. Create a project at supabase.com
2. Go to SQL Editor → paste in `supabase/schema.sql` → run it
3. Go to Authentication → create your own user (this becomes your HOC or
   super admin login) — you can create separate users for each role
4. To make a user a super admin, run in the SQL editor:
   ```sql
   insert into super_admins (user_id)
   values ('paste-the-user-uuid-here');
   ```
5. Copy your Project URL and anon key (Settings → API) into `.env.local`
6. Copy your service role key (Settings → API, "service_role" — keep this
   secret) into `.env.local` as well — it's only used server-side in the
   PDF export route

## 3. Deploy (free)

1. Push this project to a GitHub repo
2. Import the repo at vercel.com → it auto-detects Next.js
3. Add the same environment variables from `.env.local` in Vercel's
   project settings
4. Deploy — you'll get a free `yourapp.vercel.app` link

## 4. PWA install

Once deployed, visiting the site on a phone and choosing "Add to Home
Screen" installs it like an app — no app store needed. Replace the
placeholder icons in `public/icons/` with your real logo before launch.
