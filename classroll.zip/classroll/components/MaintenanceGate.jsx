"use client";

import { useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { supabase } from "@/lib/supabaseClient";

// Routes that must stay reachable even during maintenance, so the
// super admin can always log in and flip the switch back.
const EXEMPT_PREFIXES = ["/superadmin"];

export default function MaintenanceGate({ children }) {
  const pathname = usePathname();
  const [status, setStatus] = useState("checking"); // checking | live | maintenance

  const isExempt = EXEMPT_PREFIXES.some((prefix) => pathname.startsWith(prefix));

  useEffect(() => {
    if (isExempt) {
      setStatus("live");
      return;
    }

    let active = true;

    async function checkStatus() {
      const { data, error } = await supabase
        .from("app_settings")
        .select("app_status")
        .eq("id", 1)
        .single();

      if (!active) return;

      if (error || !data) {
        // Fail open rather than locking everyone out on a network blip.
        setStatus("live");
        return;
      }

      setStatus(data.app_status === "maintenance" ? "maintenance" : "live");
    }

    checkStatus();
    return () => {
      active = false;
    };
  }, [isExempt, pathname]);

  if (status === "checking") {
    return null;
  }

  if (status === "maintenance") {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center text-center px-6">
        <h1 className="text-2xl font-semibold mb-2">We&apos;ll be back shortly</h1>
        <p className="text-gray-500 max-w-sm">
          ClassRoll is undergoing a quick update. Your existing data is safe —
          please check back in a few minutes.
        </p>
      </div>
    );
  }

  return children;
}
