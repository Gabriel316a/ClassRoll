export default function Footer() {
  return (
    <footer className="w-full text-center py-4 text-sm text-gray-500 flex items-center justify-center gap-2 mt-auto">
      <span aria-hidden="true">💡</span>
      <span>Innovation Hub</span>
    </footer>
  );
}
